
    <h1>Hello, <?= $nama; ?>!</h1>

 